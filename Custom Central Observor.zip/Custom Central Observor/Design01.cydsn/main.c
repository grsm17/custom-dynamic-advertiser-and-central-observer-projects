/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

uint8 BLE_TX_Array[20]; //limited by mtu size
uint8 j=0;

//function for print f use
/* For GCC compiler revise _write() function for printf functionality */
int _write(int file, char *ptr, int len)
{
    int i;
    file = file;
    for (i = 0; i < len; i++)
    {
        UART_UartPutChar(*ptr++);
    }
    return len;
}

CYBLE_GATTC_WRITE_REQ_T 	BLEdata; //handle to store data to be sent over ble connection

uint8 devIndex;         // Index of the devices detected in Scanning
uint8 Periph_Selected;  // The Index of the Peropheral which the user wants to connect the Central 

void StackEventHandler(uint32 event, void *eventparam);	
 
/* 'connHandle' is a varibale of type 'CYBLE_CONN_HANDLE_T' (defined in 
* BLE_StackGatt.h) and is used to store the connection handle parameters after
* connecting with the peripheral device. */
CYBLE_CONN_HANDLE_T			connHandle;

	/* 'apiResult' is a varibale of type 'CYBLE_API_RESULT_T' (defined in 
* BLE_StackTypes.h) and is used to store the return value from BLE APIs. */
	
CYBLE_API_RESULT_T 		    apiResult;
	
/* 'connectPeriphDevice' is a varibale of type 'CYBLE_GAP_BD_ADDR_T' (defined in 
* BLE_StackGap.h) and is used to store address of the connected device. */
CYBLE_GAP_BD_ADDR_T     connectPeriphDevice[10];

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    char8 command; //variable to store entered UART value
    char8 command1;//variable to store entered UART value
    char8 command2;//variable to store entered UART value
    uint8 flag1 = 0;//flag to help with position in a loop
    uint8 flag2 = 0;//flag to help with position in a loop
    uint8 d=0;//counter
    
   
    
    CyBle_Start (StackEventHandler);	//start the BLE core and reference the stack call back
	
	/* Start UART Component which is used for receiving inputs and Debugging */
    UART_Start();
	printf("simple central \r\n");
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    CyBle_ProcessEvents();
    for(;;)
    {
        CyBle_ProcessEvents();
        command = UART_UartGetChar(); //get latest uart value
        if(command != 0u) //if not = to zero
        {
            // The user has to Enter D for disconnection  
            if (command == 'D' || command == 'd')  // The user has to Enter D for disconnection 
            {
                printf ("Attempting Disconnection\r\n");
                apiResult= CyBle_GapDisconnect(connHandle.bdHandle);//disconnect the current peripheral
                printf("\r\n apiRes %d\r\n", apiResult);
                CyBle_ProcessEvents();
                devIndex= 0; //zero the flags and pointers
                flag1=0;
                flag2=0;
            }
        
            else if (command =='C' || command == 'c') //to connect to a device
            {
                
                printf ("enter connect number\r\n");
                while(flag1 ==0)
                {
                    command1 = UART_UartGetChar(); //get latest uart value
                    CyBle_ProcessEvents();
                    // Check if a Valid Device index has been received
                    if (command1 != 0u) 
                    {
                        Periph_Selected = (uint8)(command1 - '0');//select the enterred peripheral (removing the first digit for hex)
                       
                        flag1=1; //set the flag to exit loop
                        printf("%c \r\n", command1); /* print number */
                        
                        //Stop the scanning before connecting to the preferred peripheral
                        if(CyBle_GetState() != CYBLE_STATE_CONNECTING)
                        {
                            CyBle_GapcStopScan();
                        }
                        else
                        {
                             printf("Trying to connect to previous device.\r\n");
                        }
                        CyBle_ProcessEvents();
                        

                        apiResult = CyBle_GapcConnectDevice(&connectPeriphDevice[Periph_Selected]); //connect to the selected device
    			        if(CYBLE_ERROR_OK != apiResult )
    			        {
    			        printf ("Connection Request to peripheral failed \r\n");
                        flag1=0;
    			        }
                        else
                        {
                        printf ("Connection Request Sent to Peripheral \r\n");
                        printf ("Press E to enter data to be sent \r\n");
                        
                        }
                    }//end of if command1
                      
                }//end of while
               flag1=0;
            }//end of if c check
            
            else if (command == 'E' || command == 'e') //te enter data to be sent
            {
                
                while(flag2==0)
                {
                command2 = UART_UartGetChar(); //get latest uart value
                CyBle_ProcessEvents();
                
                if(command2 != 0u) //if not = to zero
                {
                switch(command2)
                {  
                    case 0xD: //carriage return command - display the entered text in its entirety
                        
                        BLEdata.attrHandle = 0x0012u; //0x0012 matches the value of the handle declared in the peripheral. may need changing
			            BLEdata.value.val = BLE_TX_Array;
			            BLEdata.value.len = sizeof(BLE_TX_Array);
                        BLEdata.value.actualLen=sizeof(BLE_TX_Array);
			            apiResult = CyBle_GattcWriteCharacteristicValue(connHandle, &BLEdata); //send write commannd and check the command was executed ok
			            
                        printf("\r\n apiRes %d\r\n", apiResult);
			            printf("\r\ndata sent\r\n"); 
                        CyBle_ProcessEvents();
			   
                        flag2=1;//set flag to exit loop
                    
                        d=0; //reset pointer for future entries
                        
                    break;

                    case 0x1B: //escape
                        printf("\r\nEscape\r\n"); 
                        d=0;//reset pointer to start
                    break;                
                        
                    default:
                        BLE_TX_Array[d] = command2; //store character in array
                        printf("    char: %c\r\n", command2); //echo back to terminal
                        d++;//increment counter
                    break;

                }//end of switch
                }
            }//end of if command
                flag2=0;
            }
            else
            {
                //
            }
		}//end of if command not 0
        
        //Function to handle connection and disconnecton
		
    }//end of for
}//end of main


void Get_Adv_Scan_Packets(CYBLE_GAPC_ADV_REPORT_T* scanReport)
{
    uint8 RepIndex; //Index for Bytes in Adv Packet

  
    // Receiving Advertisement Packet
    
    //if the type of advertising packet is undirected connectable or non connectable
    //look at the content of the adv packet
    if ((scanReport->eventType == CYBLE_GAPC_CONN_UNDIRECTED_ADV)||
    (scanReport->eventType == 	CYBLE_GAPC_NON_CONN_UNDIRECTED_ADV))
    {
               
         if(scanReport->data[8] == 0x78) //if the 8th byte is equal to 'x' (first 5 bytes are flags then PIR)
        {
            
            devIndex = 4; //set marker to 4
            printf ("Found Device %x \r\n", devIndex);
            
            //copy the bdaddr locally 
            memcpy(connectPeriphDevice[devIndex].bdAddr, scanReport->peerBdAddr,
                sizeof(connectPeriphDevice[devIndex].bdAddr));
            printf("Peer device adveritsing data Length: %d \r\n", scanReport->dataLen);
            
            
            //print the entire advertising packet values
            for(RepIndex = 0u; RepIndex < scanReport->dataLen; RepIndex++)
            {
                printf("%x", scanReport->data[RepIndex]);
            }
            printf("\r\n");
            printf("RSSI: %d \r\n",scanReport->rssi);
            printf("peerBdAddr: %x%x%x%x%x%x \r\n",
            scanReport->peerBdAddr[5u], 
            scanReport->peerBdAddr[4u], 
            scanReport->peerBdAddr[3u], 
            scanReport->peerBdAddr[2u], 
            scanReport->peerBdAddr[1u], 
            scanReport->peerBdAddr[0u]);          
        
        }//end if else
        else if(scanReport->data[8] == 0x31) ////if the 8th byte is equal to '1' (first 5 bytes are flags then PIR)
        {
            devIndex = 1;//set marker to 1
            printf ("Found Device %x \r\n", devIndex);
            
             //copy the bdaddr locally 
            memcpy(connectPeriphDevice[devIndex].bdAddr, scanReport->peerBdAddr,
                sizeof(connectPeriphDevice[devIndex].bdAddr));
            printf("Peer device adveritsing data Length: %d \r\n", scanReport->dataLen);
            
            
            //print the entire advertising packet values
            for(RepIndex = 0u; RepIndex < scanReport->dataLen; RepIndex++)
            {
                printf("%x", scanReport->data[RepIndex]);
            }
            printf("\r\n");
            printf("RSSI: %d \r\n",scanReport->rssi);
            printf("peerBdAddr: %x%x%x%x%x%x \r\n",
            scanReport->peerBdAddr[5u], 
            scanReport->peerBdAddr[4u], 
            scanReport->peerBdAddr[3u], 
            scanReport->peerBdAddr[2u], 
            scanReport->peerBdAddr[1u], 
            scanReport->peerBdAddr[0u]);          
        
        
        }//end else if
        else if(scanReport->data[8] == 0x32) //if the 8th byte is equal to '2' (first 5 bytes are flags then PIR)
        {
            devIndex = 2;//set marker to 2
            printf ("Found Device %x \r\n", devIndex);
            
            memcpy(connectPeriphDevice[devIndex].bdAddr, scanReport->peerBdAddr,
                sizeof(connectPeriphDevice[devIndex].bdAddr));
            printf("Peer device adveritsing data Length: %d \r\n", scanReport->dataLen);
            
            for(RepIndex = 0u; RepIndex < scanReport->dataLen; RepIndex++)
            {
                printf("%x", scanReport->data[RepIndex]);
            }
            printf("\r\n");
            printf("RSSI: %d \r\n",scanReport->rssi);
            printf("peerBdAddr: %x%x%x%x%x%x \r\n",
            scanReport->peerBdAddr[5u], 
            scanReport->peerBdAddr[4u], 
            scanReport->peerBdAddr[3u], 
            scanReport->peerBdAddr[2u], 
            scanReport->peerBdAddr[1u], 
            scanReport->peerBdAddr[0u]);
            
        }//end else if
        else if(scanReport->data[8] == 0x33) //if the 8th byte is equal to '3' (first 5 bytes are flags then PIR)
        {
            devIndex = 3;//set marker to 3
            printf ("Found Device %x \r\n", devIndex);
            
            //copy the bdaddr locally 
            memcpy(connectPeriphDevice[devIndex].bdAddr, scanReport->peerBdAddr,
                sizeof(connectPeriphDevice[devIndex].bdAddr));
            printf("Peer device adveritsing data Length: %d \r\n", scanReport->dataLen);
            
            
            //print the entire advertising packet values
            for(RepIndex = 0u; RepIndex < scanReport->dataLen; RepIndex++)
            {
                printf("%x", scanReport->data[RepIndex]);
            }
            printf("\r\n");
            printf("RSSI: %d \r\n",scanReport->rssi);
            printf("peerBdAddr: %x%x%x%x%x%x \r\n",
            scanReport->peerBdAddr[5u], 
            scanReport->peerBdAddr[4u], 
            scanReport->peerBdAddr[3u], 
            scanReport->peerBdAddr[2u], 
            scanReport->peerBdAddr[1u], 
            scanReport->peerBdAddr[0u]);         
        
        }//end else if
    
    }//end if undirected
}//end of function

    
		

/*******************************************************************************
* Function Name: StackEventHandler
********************************************************************************
* Summary:
*        Call back event function to handle various events from BLE stack
*
* Parameters:
*  event:		event returned
*  eventParam:	link to value of the event parameter returned
*
* Return:
*  void
*
*******************************************************************************/
void StackEventHandler(uint32 event, void *eventParam)
{
	CYBLE_GAPC_ADV_REPORT_T advReport; //variable to store advertising report data
   

	switch(event)
	{
		case CYBLE_EVT_STACK_ON:
            printf("BLE ON:Started to Scan\r\n");
           
	        if(CYBLE_ERROR_OK == CyBle_GapcStartScan(CYBLE_SCANNING_FAST)) //if scanning starts ok turn green led on
	        {
              GREEN_Write(0);
	        }
			break;   
			
		case CYBLE_EVT_GAPC_SCAN_PROGRESS_RESULT:
                /*Get the information from advertisement and scan response packets*/
             Get_Adv_Scan_Packets((CYBLE_GAPC_ADV_REPORT_T *)eventParam);
             memcpy(&advReport, eventParam, sizeof(advReport)); 

		break;
			
 		case CYBLE_EVT_GATT_CONNECT_IND:
			/* When the peripheral device is connected, store the connection handle.*/
        
            connHandle = *(CYBLE_CONN_HANDLE_T *)eventParam;
                        
			break;
		
		case CYBLE_EVT_GAP_DEVICE_CONNECTED:
             //devIndex = 0;
	         printf("Peripheral connected. Press 'D' for disconnection \r\n");
             CyBle_GattcStartDiscovery(connHandle);//start service discovery
            GREEN_Write(1);

            
        break;
			
		case CYBLE_EVT_GAP_DEVICE_DISCONNECTED:
            
            //on disconnect restart scanning
              if(CYBLE_ERROR_OK != CyBle_GapcStartScan(CYBLE_SCANNING_FAST))
    	       {
                 printf ("Start Scanning Failed");
               }
               else
               {
                 
                 printf ("disconnected Scanning\r\n");
                 GREEN_Write(0);
                
                
               }
            
           break;
            
        case CYBLE_EVT_GATTC_WRITE_RSP:
		    //if a write to the peripheral is successful we should receive a write response so check it is received	
			printf ("CYBLE_EVT_GATTC_WRITE_RSP\r\n ");
			
		    break;

		default:
			break;
	}
}
/* [] END OF FILE */
