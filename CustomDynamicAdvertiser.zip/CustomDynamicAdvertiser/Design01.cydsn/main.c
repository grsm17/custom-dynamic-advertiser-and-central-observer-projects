/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>


//the project increments 2 bytes in the advertising packet every 2 seconds in a wdt isr.
//if connected over ble, the user can dynamically change all the bytes in the advertising packet
//if connected over uart they can update some bytes.
//optional debug and low power can be implemented, as well as storing the new advertising address to flash

/* Array to store the present RGB LED control data. The 4 bytes 
* of the array represents {R,G,B,Intensity} */
uint8 RGBledData[4];

//function for print f use
/* For GCC compiler revise _write() function for printf functionality */
int _write(int file, char *ptr, int len)
{
    int i;
    file = file;
    for (i = 0; i < len; i++)
    {
        UART_UartPutChar(*ptr++);
    }
    return len;
}

//



#define DEBUG //enables print f functions at certain stages
//#define FLASH_STORE //if enabled, stores written ble data to flash to be used as new advertising address
#define CONNECTABLE     1   //to be used to change adv packet type
#define BEACON          2   //to be used to change adv packet type
//define LOW_POWER  //enables low power mode and operation

uint8 StoredAddress[CY_SFLASH_SIZEOF_USERROW]; //variable to read and write data to flash
cystatus returnValue = CYRET_SUCCESS; //test condition for flash write

/* Defines last ROW of SFlash */
#define CY_TEST_SFLASH_ROW       (CY_SFLASH_NUMBER_USERROWS - 1u)
/* Defines absolute address of ROW */
#define CY_TEST_SFLASH_ADDR      (CY_SFLASH_USERBASE + CY_TEST_SFLASH_ROW * CY_SFLASH_SIZEOF_USERROW)
   

/* Interrupt prototype */
CY_ISR_PROTO(WdtIsrHandler); //declaration for custom declare of the wdt isr


void StackEventHandler( uint32 eventCode, void *eventParam ); //declaration of stack event handler
void ReadFlashAddress(void); //declaration of read flash function
void WriteFlashAddress(void); //declaration of write flash function
void Change_Adv_Type(uint8 Type); //declaration of function to select type of advertising packet to be sent
void EnterLowPowerMode(void);
void UpdateRGBled(void);

CYBLE_GAPP_DISC_DATA_T  new_advData; //structure to update advertising data
uint8 i=0;//counter used in uart code
uint8 j=0;//counter used in ble write 
char AdvertisingArray[31]; //array to store entered uart data. made 31 bytes to mimic max payload of the advertising packet
#define ADV_PACKET_LENGTH   31u //macro value to override adv packet length
uint8 BLE_RX_Array[32]; //array to store written ble data
uint8 interruptCnt = 0u; //interrupt counter to keep track of how many wdt events

int main(void)
{
    
    CySysWdtEnable(CY_SYS_WDT_COUNTER0_MASK); //enable the wdt interrupt. the frequecncy is in the cydwr.clocks section

    WdtIsr_StartEx(WdtIsrHandler);    /* Start ISR for wdt */
    
    
    PWM1_Start();
    PWM2_Start();
    PWM3_Start();
    
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    UART_Start();//start the uart for debug and text entry
    #ifdef FLASH_STORE
    ReadFlashAddress();
    #endif
    cyBle_discoveryModeInfo.advData->advDataLen = ADV_PACKET_LENGTH; //set to max value
    CyBle_Start( StackEventHandler ); //start BLE core
  
    CyBle_ProcessEvents(); //process any ble events
    
    Change_Adv_Type(CONNECTABLE); //select connectable type of packets and start advertising
    

    for(;;)
    {
        char8 command; //variable to store entered UART value
       
        CyBle_ProcessEvents(); //call to make sure we don't miss any stack events
	 
        
        command = UART_UartGetChar(); //get latest uart value
            if(command != 0u) //if not = to zero
            {
                switch(command)
                {  
                    case 0xD: //carriage return command - display the entered text in its entirety
                        
                        CyBle_GappExitDiscoveryMode(); //stop advertising whilst we update the last 8 bytes of advertising data
                       
                        new_advData = *cyBle_discoveryModeInfo.advData;//copy the existing advertising data to our structure
                        //the first 5 bytes of the advertising packet are flags.
                        //new user data/name can go from new_advData.advData[5]
                        //for demo purposes we will put the first 8 bytes typed in in to 9-16
                        
                        new_advData.advData[9] = AdvertisingArray[0]; //update the last 8 bytes with entered data
                        new_advData.advData[10] = AdvertisingArray[1];
                        new_advData.advData[11] = AdvertisingArray[2];
                        new_advData.advData[12] = AdvertisingArray[3];
                        new_advData.advData[13] = AdvertisingArray[4];
                        new_advData.advData[14] = AdvertisingArray[5];
                        new_advData.advData[15] = AdvertisingArray[6];
                        new_advData.advData[16] = AdvertisingArray[7];
                        
                        cyBle_discoveryModeInfo.advData = &new_advData;  //pass the updated advertising data back
                        cyBle_discoveryModeInfo.advData->advDataLen = ADV_PACKET_LENGTH; //set to max value
                        CyBle_GappEnterDiscoveryMode(&cyBle_discoveryModeInfo);//restart broadcast / advertising mode
                        
                        i=0; //reset pointer for future entries
                        
                    break;

                    case 0x1B: //escape
                        printf("\r\nEscape\r\n"); 
                        i=0;//reset pointer to start
                    break;                
                        
                    default:
                        AdvertisingArray[i] = command; //store character in array
                        printf("    char: %c\r\n", command); //echo back to terminal
                        i++;//increment counter
                    break;

                }//end of switch
            }//end of if command
            #ifdef LOW_POWER
            EnterLowPowerMode();
            ////if low power is used add call below to update adv data here rather than in wdt isr
            CyBle_GapUpdateAdvData(cyBle_discoveryModeInfo.advData, cyBle_discoveryModeInfo.scanRspData); //update teh adv parameters that have been se set in isr
            #endif
    }//end of for;;
}//end of main


void StackEventHandler( uint32 eventCode, void *eventParam )
{
    
    CYBLE_GATTS_WRITE_REQ_PARAM_T *writeRequest;
    CYBLE_GATT_HANDLE_VALUE_PAIR_T		localCopyHandle;
    
    switch( eventCode )
    {
        /* Generic events */

        case CYBLE_EVT_STACK_ON:
        
        //we would normally start BLE advertising here but we are doing it manaully in code
            #ifdef DEBUG
           printf("stack on\r\n");
            #endif
            break;

        
        case CYBLE_EVT_GAPP_ADVERTISEMENT_START_STOP:
            #ifdef DEBUG
            printf("start stop event on\r\n");
            #endif    
            CyBle_GappEnterDiscoveryMode(&cyBle_discoveryModeInfo);//restart broadcast / advertising mode
                        
            break;
            
        case CYBLE_EVT_GAP_DEVICE_CONNECTED:
           printf("connected\r\n");
            break;
            
        case CYBLE_EVT_GAP_DEVICE_DISCONNECTED:
            
            CyBle_GappEnterDiscoveryMode(&cyBle_discoveryModeInfo);//restart broadcast / advertising mode
             printf("disconnected\r\n");
            break;
            
        case CYBLE_EVT_GATT_CONNECT_IND:
            
            break;
            
        case CYBLE_EVT_GATT_DISCONNECT_IND:
                        
            break;    
         
        case CYBLE_EVT_GATTS_WRITE_REQ:   //if we receive a write request do check which characteristic it was to
            
            writeRequest = (CYBLE_GATTS_WRITE_REQ_PARAM_T *)eventParam;
                printf("wr\r\n");
            //if it was to our custom service
            if(writeRequest->handleValPair.attrHandle == CYBLE_CONFIGSERVICE_CONFIGDATA_CHAR_HANDLE)
            {
                //copy the max array size (32 bytes in this example)
                for(j=0;j<32;j++) 
                {
                    BLE_RX_Array[j]=writeRequest->handleValPair.value.val[j];
                    printf("    ble data: %x", BLE_RX_Array[j]); //echo back to terminal
                }
                    PWM1_WriteCompare(BLE_RX_Array[0]);
                    PWM2_WriteCompare(BLE_RX_Array[1]);
                    PWM3_WriteCompare(BLE_RX_Array[2]);
           
                    
                   // UpdateRGBled();
                //the next 5 lines write the recieved data to the GATT DB so that if we perform a read request the data is correct
                localCopyHandle.attrHandle = CYBLE_CONFIGSERVICE_CONFIGDATA_CHAR_HANDLE;
            	localCopyHandle.value.val = BLE_RX_Array;
            	localCopyHandle.value.len = sizeof(BLE_RX_Array);
            	localCopyHandle.value.actualLen = sizeof(BLE_RX_Array);
            	
            	/* Send updated  handle as attribute for read by central device */
            	CyBle_GattsWriteAttributeValue(&localCopyHandle, 0, &cyBle_connHandle, 0); 
                
                //if the 5th byte is a non zero byte we will update the PIR number and sub net address
                //this can be changed to an other byte and the array below can be modiifed as you wish
                if(BLE_RX_Array[4] != 0x00) 
                {
                   
                    //copy the data in to the advertising packets 
                    cyBle_discoveryModeInfo.advData->advData[8] = BLE_RX_Array[4];
                    cyBle_discoveryModeInfo.advData->advData[9] = BLE_RX_Array[5];
                    cyBle_discoveryModeInfo.advData->advData[10] = BLE_RX_Array[6]; 
                    cyBle_discoveryModeInfo.advData->advData[11] = BLE_RX_Array[7]; 
                    cyBle_discoveryModeInfo.advData->advData[12] = BLE_RX_Array[8]; 
                    cyBle_discoveryModeInfo.advData->advData[13] = BLE_RX_Array[9]; 
                    cyBle_discoveryModeInfo.advData->advData[14] = BLE_RX_Array[10]; 
                    cyBle_discoveryModeInfo.advData->advData[15] = BLE_RX_Array[11]; 
                    cyBle_discoveryModeInfo.advData->advData[16] = BLE_RX_Array[12]; 
                
                    //instruct the ble core to use the updated information
                    CyBle_GapUpdateAdvData(cyBle_discoveryModeInfo.advData, cyBle_discoveryModeInfo.scanRspData);//this command updates the advertising data with new information
                    
                    

                    
                    #ifdef FLASH_STORE
                
                    //we can use the following section to store the updated advertising address to flash 
                    //so that after a power cycle we don't need to re commission the address data
    			    WriteFlashAddress();
     			    #endif
			
                }//end of if byte 4 test
            }//end of if write handler
		
			/* As part of every write request, the server needs to send a write response. Note
			* that this will be sent only if all the application layer conditions are met on a 
			* write request. Else, an appropriate error code is sent. */
	        CyBle_GattsWriteRsp(cyBle_connHandle);
            
            break;
            
        default:
            break;
    }
}
/*******************************************************************************
* Function Name: EnterLowPowerMode
********************************************************************************
*
* Summary:
*  This configures the BLESS and system in low power mode whenever possible.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void EnterLowPowerMode(void)
{
    /* Local variable to store the status of BLESS Hardware block */
		CYBLE_LP_MODE_T sleepMode;
		CYBLE_BLESS_STATE_T blessState;
		
		#ifdef CAPSENSE_ENABLED
		/* Put CapSense to Sleep*/
		CapSense_Sleep();
		#endif
		
		/* Put BLESS into Deep Sleep and check the return status */
		sleepMode = CyBle_EnterLPM(CYBLE_BLESS_DEEPSLEEP);
		
		/* Disable global interrupt to prevent changes from any other interrupt ISR */
		CyGlobalIntDisable;
	
		/* Check the Status of BLESS */
		blessState = CyBle_GetBleSsState();

		if(sleepMode == CYBLE_BLESS_DEEPSLEEP)
		{
		    /* If the ECO has started or the BLESS can go to Deep Sleep, then place CPU 
			* to Deep Sleep */
			if(blessState == CYBLE_BLESS_STATE_ECO_ON || blessState == CYBLE_BLESS_STATE_DEEPSLEEP)
		    {
				
					/* Put PrISM modules to sleep */
					PWM1_Sleep();
					PWM2_Sleep();
                    PWM3_Sleep();
					RED_SetDriveMode(RED_DM_ALG_HIZ);
			        GREEN_SetDriveMode(GREEN_DM_ALG_HIZ);
			        BLUE_SetDriveMode(BLUE_DM_ALG_HIZ);
                    
					
					/* Place CPU to Deep sleep only when the RGB PrISM module is not 
					* active (indicated by flag 'shut_down_led'). 
					* If RGB PrISM is active, then the CPU should only be placed in 
					* Sleep to allow the PrISM to function and control the color 
					* and Intensity */
			        CySysPmDeepSleep();
					
					/* After system wakes up, wake up the PrISM modules*/
                    RED_SetDriveMode(RED_DM_STRONG);
			        GREEN_SetDriveMode(GREEN_DM_STRONG);
			        BLUE_SetDriveMode(BLUE_DM_STRONG);
					PWM1_Wakeup();
					PWM2_Wakeup();
                    PWM3_Wakeup();
				
		 	}
            
		}
		else
		{
		    if(blessState != CYBLE_BLESS_STATE_EVENT_CLOSE)
		    {
				/* If the BLESS hardware block cannot go to Deep Sleep and BLE Event has not 
				* closed yet, then place CPU to Sleep */
		        CySysClkWriteImoFreq(3u);
                CySysPmSleep();
                CySysClkWriteImoFreq(24u);
		    }
		}
		
		/* Re-enable global interrupt mask after wakeup */
		CyGlobalIntEnable;
		
	
}

   

/*******************************************************************************
* Function Name: WdtIsrHandler
********************************************************************************
* Summary:
*  The interrupt handler for WDT counter 0 interrupts. 
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
CY_ISR(WdtIsrHandler)
{
   
    /* Clear Interrupt */
    WdtIsr_ClearPending();
    /* Clear interrupts state */
    CySysWdtClearInterrupt(CY_SYS_WDT_COUNTER0_INT);

 
    /* Interrupt happened counter */
    interruptCnt++;
    #ifdef DEBUG
    printf("intcnt: %d\r\n", interruptCnt); //echo back to terminal
    #endif
    
    //load the 18 and 19th bytes of the advertising packet with new data. in this example this is the interrupt counter but 
    //could be from a sensor reading
    cyBle_discoveryModeInfo.advData->advData[17]= interruptCnt;
    cyBle_discoveryModeInfo.advData->advData[18]= (interruptCnt*2);
   
    //this command updates the advertising data with new information - passed in to main loop to work with low power
    #ifndef LOW_POWER
    CyBle_GapUpdateAdvData(cyBle_discoveryModeInfo.advData, cyBle_discoveryModeInfo.scanRspData);
    #endif
    
}//end of isr handler


void ReadFlashAddress(void)
{
    StoredAddress[0] = (*((uint8 *) (CY_TEST_SFLASH_ADDR + 0)));
    
 
    if(StoredAddress[0] != 0x78) //if not equal to "x"
    {
       //read the flash values in to the temporary array
        StoredAddress[0] = (*((uint8 *) (CY_TEST_SFLASH_ADDR + 0)));
        StoredAddress[1] = (*((uint8 *) (CY_TEST_SFLASH_ADDR + 1)));
        StoredAddress[2] = (*((uint8 *) (CY_TEST_SFLASH_ADDR + 2)));
        StoredAddress[3] = (*((uint8 *) (CY_TEST_SFLASH_ADDR + 3)));
        StoredAddress[4] = (*((uint8 *) (CY_TEST_SFLASH_ADDR + 4)));
        StoredAddress[5] = (*((uint8 *) (CY_TEST_SFLASH_ADDR + 5)));
        StoredAddress[6] = (*((uint8 *) (CY_TEST_SFLASH_ADDR + 6)));
        StoredAddress[7] = (*((uint8 *) (CY_TEST_SFLASH_ADDR + 7)));
        StoredAddress[8] = (*((uint8 *) (CY_TEST_SFLASH_ADDR + 8)));
        
        //pass those values to the ble advertising information
        cyBle_discoveryModeInfo.advData->advData[8] = StoredAddress[0];
        cyBle_discoveryModeInfo.advData->advData[9] = StoredAddress[1];
        cyBle_discoveryModeInfo.advData->advData[10] = StoredAddress[2]; 
        cyBle_discoveryModeInfo.advData->advData[11] = StoredAddress[3]; 
        cyBle_discoveryModeInfo.advData->advData[12] = StoredAddress[4]; 
        cyBle_discoveryModeInfo.advData->advData[13] = StoredAddress[5]; 
        cyBle_discoveryModeInfo.advData->advData[14] = StoredAddress[6]; 
        cyBle_discoveryModeInfo.advData->advData[15] = StoredAddress[7]; 
        cyBle_discoveryModeInfo.advData->advData[16] = StoredAddress[8]; 
    
        //we call this before start of BLE. if called when the ble is running, you will need to call the update function
    }
}


//function to write received data to flash to store the configuration
void WriteFlashAddress(void)
{
    //load values in to temp array
    StoredAddress[0] = cyBle_discoveryModeInfo.advData->advData[8];
    StoredAddress[1] = cyBle_discoveryModeInfo.advData->advData[9];
    StoredAddress[2] = cyBle_discoveryModeInfo.advData->advData[10];
    StoredAddress[3] = cyBle_discoveryModeInfo.advData->advData[11];
    StoredAddress[4] = cyBle_discoveryModeInfo.advData->advData[12];
    StoredAddress[5] = cyBle_discoveryModeInfo.advData->advData[13];
    StoredAddress[6] = cyBle_discoveryModeInfo.advData->advData[14];
    StoredAddress[7] = cyBle_discoveryModeInfo.advData->advData[15];
    StoredAddress[8] = cyBle_discoveryModeInfo.advData->advData[16];
    
    //write them to flash
    returnValue = CySysSFlashWriteUserRow(CY_TEST_SFLASH_ROW, StoredAddress);       

    /* Check if operation is successful */

    if (returnValue != CY_SYS_SFLASH_SUCCESS)
    {
        CyHalt(0x00u); //if write fails do something. here we halt the processor
    }
}


void Change_Adv_Type(uint8 Type)
{
    if(Type==CONNECTABLE)
    {
    
        CyBle_GappExitDiscoveryMode();
        
        cyBle_discoveryModeInfo.advParam->advType = CYBLE_GAPP_CONNECTABLE_UNDIRECTED_ADV; //connectable
    
        CyBle_GappEnterDiscoveryMode(&cyBle_discoveryModeInfo);//start advertising mode
        
    }
    else if(Type==BEACON)
    {
        CyBle_GappExitDiscoveryMode();
        
        cyBle_discoveryModeInfo.advParam->advType = CYBLE_GAPP_NON_CONNECTABLE_UNDIRECTED_ADV; //beacon only
        
        CyBle_GappEnterDiscoveryMode(&cyBle_discoveryModeInfo);//start advertising mode
    }
}


void UpdateRGBled(void)
{
	/* Local variables to calculate the color components from RGB received data*/
    PWM1_WriteCompare(RGBledData[0]);
	PWM2_WriteCompare(RGBledData[1]);	
	PWM3_WriteCompare(RGBledData[2]);

}

/* [] END OF FILE */
